export const APP_URL = "http://localhost:3000/";
