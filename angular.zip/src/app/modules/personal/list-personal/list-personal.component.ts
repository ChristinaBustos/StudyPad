import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-personal',
  templateUrl: './list-personal.component.html'
})
export class ListPersonalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
