import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-position',
  templateUrl: './main-position.component.html'
})
export class MainPositionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
