import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-user',
  templateUrl: './main-user.component.html'
})
export class MainUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
