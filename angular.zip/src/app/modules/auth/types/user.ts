import { FormControl } from "@angular/forms";

export type User = {
  email: string;
  contrasenia: string;
};
