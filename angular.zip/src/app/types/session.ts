export type Session = {
  logged: boolean
}