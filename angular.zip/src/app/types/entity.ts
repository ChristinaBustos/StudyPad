export type Entity<Tidentifier extends number | string> = {
  id?: Tidentifier;
};
